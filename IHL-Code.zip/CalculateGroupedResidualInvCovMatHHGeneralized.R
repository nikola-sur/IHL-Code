# This function obtains the (generalized) inverse of Sigma_n in the GHL test.
# It is similar to the work by Hosmer/Hjort (2002).
#
# Parameters ---
# obj: The glm object
# G: The matrix specifying which observations fall into which group
#
# Created: June 25, 2018
# Libraries: "Matrix"

CalculateGroupedResidualInvCovMatHHGeneralized <- function (obj, G) {
  # Get dispersion parameter and variance of observations
  muHat <- obj$fitted.values
  phi <- summary(obj)$dispersion
  varVec <- family(obj)$variance(muHat) * phi

  Vsqrt <- diag(sqrt(varVec))
  H <- GetHatMatrix(obj)
  n <- nrow(H)
  I <- diag(rep(1, n))
  GVsqrt <- G %*% Vsqrt

  OmegaHat <- 1/n * GVsqrt %*% (I - H) %*% t(GVsqrt)
  OmegaHatInv <- MASS::ginv(OmegaHat) # Moore-Penrose inverse (see Moore 1977)

  rankOmegaHatInv <- Matrix::rankMatrix(OmegaHatInv)[[1]]

  return(list(
    matrix = OmegaHatInv,
    rank   = rankOmegaHatInv))
}
