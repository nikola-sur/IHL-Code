# Examples of clustering in the covariate space

rm(list=ls())

library(mvtnorm)

set.seed(8636284)
d <- 3
s2_e_vec <- c(0.001, 0.01, 0.1)
s2 <- 1
m <- 100
ss <- 500

x <- rmvnorm(n=m, mean=rep(0, d-1), sigma=diag(x=s2, nrow=(d-1), ncol=(d-1))) # m cluster centers
x <- x[rep(1:nrow(x), each=ss/m), ] # Create n/m replicates in each cluster
x2 <- x + rmvnorm(n=ss, mean=rep(0, d-1), sigma=diag(x=s2_e_vec[1], nrow=(d-1), ncol=(d-1))) # Add noise to each observation
x3 <- x + rmvnorm(n=ss, mean=rep(0, d-1), sigma=diag(x=s2_e_vec[2], nrow=(d-1), ncol=(d-1))) # Add noise to each observation
x4 <- x + rmvnorm(n=ss, mean=rep(0, d-1), sigma=diag(x=s2_e_vec[3], nrow=(d-1), ncol=(d-1))) # Add noise to each observation

plot(x[, 1], x[, 2], xlab="x1", ylab="x2", 
     xlim=c(min(x4[,1]), max(x4[,1])), ylim=c(min(x4[,2]), 3), xaxp=c(-3,3,6), yaxp=c(-3,3,6))
plot(x2[, 1], x2[, 2], xlab="x1", ylab="x2", 
     xlim=c(min(x4[,1]), max(x4[,1])), ylim=c(min(x4[,2]), 3), xaxp=c(-3,3,6), yaxp=c(-3,3,6))
plot(x3[, 1], x3[, 2], xlab="x1", ylab="x2", 
     xlim=c(min(x4[,1]), max(x4[,1])), ylim=c(min(x4[,2]), 3), xaxp=c(-3,3,6), yaxp=c(-3,3,6))
plot(x4[, 1], x4[, 2], xlab="x1", ylab="x2", 
     xlim=c(min(x4[,1]), max(x4[,1])), ylim=c(min(x4[,2]), 3), xaxp=c(-3,3,6), yaxp=c(-3,3,6))
