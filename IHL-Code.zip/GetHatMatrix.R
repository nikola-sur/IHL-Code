# This function returns the hat matrix for a GLM object.
# It should work for:
# Family: binomial, gaussian, Gamma, inverse.gaussian, poisson
# Link: logit, probit, cauchit, identity, log, inverse, cloglog, sqrt, 1/mu^2
#
# Input: obj is the GLM object
# Output: Matrix (the hat matrix)
#
# Created: June 25, 2018

GetHatMatrix <- function(obj) {
  mu <- obj$fitted.values
  eta <- obj$linear.predictors

  # Note: Dispersion parameter not necessary, since it cancels out in the hat
  # matrix equation
  phi <- summary(obj)$dispersion

  # Get partial mu / partial eta
  muEtaVec <- family(obj)$mu.eta(eta)

  # Get variances
  varVec <- family(obj)$variance(mu) * phi

  Wsqrt <- diag(muEtaVec/sqrt(varVec))
  X <- model.matrix(obj)

  # Use of 'solve' with two parameters should speed up the calculation
  WsqrtX <- Wsqrt %*% X
  H <- WsqrtX %*% solve(t(WsqrtX) %*% WsqrtX, t(WsqrtX))

  return(H)
}
