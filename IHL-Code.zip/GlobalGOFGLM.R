#' This function generalizes the HL test to a variety of GLMs.
#' In the logistic regression setting, it is similar to/the same as:
#' Tsiatis (1980), Halteman (1980), X^2_{w=1} from Hosmer and Hjort(2002)
#' For more information, see Surjanovic et al. (2020)
#'
#' @export

globalgof.glm <- function(obj, g, groupMode="equalVar", warnings=TRUE) {
  # First, check to see if we are providing the right kind of object
  stopifnot("glm" %in% class(obj))

  # Report errors in data input
  if(any(colnames(obj$model) == "(weights)")) {
    stop("Please do not provide data in EVP format.")
  }
  
  # Check that 'groupMode' provided is correct
  if (! groupMode %in% c("trials", "equalVar"))
    stop("Invalid input for parameter 'groupMode'. Use 'trials' or 'equalVar'.")

  y <- obj$y # Observed proportions, or T and F
  muHat <- obj$fitted.values

  y.o <- y[order(muHat)]
  muHat.o <- muHat[order(muHat)]

  # Get dispersion parameter and variance of observations
  phi <- summary(obj)$dispersion
  varVec <- family(obj)$variance(muHat) * phi
  varVec.o <- varVec[order(muHat)]

  # Create cutpoints
  if (groupMode == "equalVar") {
    cutpoints <- equalVarCut(pred.o = muHat.o, g=g, weights.o = varVec.o)
  } else if (groupMode == "trials") {
    cutpoints <- quantile(muHat.o, 0:g/g)
  }
  interval <- cut(muHat.o, cutpoints, include.lowest = TRUE)

  # Create contingency tables
  counts = xtabs(formula = cbind(y.o, muHat.o) ~ interval)

  sampleSize <- length(muHat)
  G <- matrix(NA, nrow=g, ncol=sampleSize)

  intervalUnO <- cut(muHat, cutpoints, include.lowest = TRUE)
  rawResids <- vector(mode='numeric',length=g)

  for (gg in (1:g)) {
    # Find the residuals that we are summing
    indTemp <- which(intervalUnO==levels(interval)[gg])
    a <- rep(0,sampleSize)
    a[indTemp] <- 1
    G[gg, ] <- a

    rawResids[gg] <- 1/sqrt(sampleSize) * (counts[gg] - counts[g+gg])
  }

  # Calculate the statistic
  invCovMatObject <- CalculateGroupedResidualInvCovMatHHGeneralized(obj, G)
  invCovMat <- invCovMatObject$matrix
  df <- invCovMatObject$rank
  chisq <- t(rawResids) %*% invCovMat %*% rawResids
  P <- 1 - pchisq(chisq, df)

  # Create a table for output
  groupedVar <- G %*% varVec
  pear <- (counts[1:g] - counts[(g+1):(2*g)])/sqrt(groupedVar)
  countsTable <- cbind(counts, pear)
  colnames(countsTable)[3] <- 'pear'

  if (any(as.numeric(groupedVar) < 5) & warnings)
    warning("Some groups might contain too few observations. Try using a smaller number of groups.")

  return(structure(list(
    method = paste0("GHL test with ", g, " groups."),
    data.name = deparse(substitute(obj)), # Gives a string
    statistic = c(X2 = chisq),
    parameter = c(df = df),
    p.value = P,
    cutpoints = cutpoints,
    countsTable = countsTable,
    G = G,
    groupedVar = groupedVar,
    rawResids = rawResids
  ), class = 'htest')) # Hypothesis test class
}
