# Hosmer-Lemeshow Test V2
#
# @param obj A logistic regression object, of class "glm"
# @param g The number of groups to use in the test
# @param groupMode One of "EVP", "trials", or "equalVar"
# @param cuts One of "quantiles", "fixed", or "equalVar"
#
# @export
# Modified by Nikola Surjanovic
#  from http://www.chrisbilder.com/categorical/Chapter5/AllGOFTests.R
#  ^ by Tom Loughin

HLTestV2 <- function(obj, g, groupMode="EVP", cuts="quantiles", warnings=TRUE) {
  # First, check to see if we fed in the right kind of object
  stopifnot(family(obj)$family == "binomial" && family(obj)$link == "logit")
  
  # Check that 'groupMode' provided is correct
  if (! groupMode %in% c("EVP","trials", "equalVar"))
    stop("Invalid input for parameter 'groupMode'. Use 'EVP' or 'trials'.")
  
  # Check that 'cuts' parameter provided is correct
  if (! cuts %in% c("quantiles","fixed", "equalVar"))
    stop("Invalid input for parameter 'cuts'. Use 'quantiles' or 'fixed'.")
  
  
  # Report errors in data or set up the proper trials
  if (groupMode == "EVP") {
    if(any(colnames(obj$model) == "(weights)")) { # Correct entry for EVP, proceed as normal
      trials <- obj$prior.weights # Get weights
    } else { # Need to aggregate and place in EVP format
      stop("Please place the data into the appropriate EVP format, and make sure the model has weights.")
    }
  } else if (groupMode=='trials' | groupMode=='equalVar') {
    if(any(colnames(obj$model) == "(weights)")) {
      stop("Please do not give data in EVP format.")
    } else { # Can proceed
      trials = rep(1, times = nrow(obj$model)) # Series of ones for each covariate combination (EVP)
      if (groupMode=='equalVar') {
        groupMode <- 'trials'
        cuts <- 'equalVar'
      }
    }
  } else {
    stop("Please specify groupMode: 'EVP' or 'trials'.")
  }
  
  y = obj$y # Observed proportions, or T and F
  
  # Convert 1-2 factor levels to logical 0/1 values
  if (is.factor(y))
    y = as.numeric(y) == 2
  yhat = obj$fitted.values
  
  if (cuts=="quantiles") {
    # CUTS AT QUANTILES OF PREDICTED VALUES
    cutpoints <- quantile(yhat, 0:g/g)
    interval = cut(yhat, quantile(yhat, 0:g/g), include.lowest = TRUE)  # Creates factor with levels 1,2,...,g
  } else if (cuts=="fixed") {
    # CUTS AT FIXED (PRE-DETERMINED) CUTPOINTS
    interval = cut(yhat,breaks=0:g/g,include.lowest = TRUE) # Evenly spaced throughout probabilities [0,1]
  } else if (cuts=="equalVar") {
    yhat.o <- yhat[order(yhat)]
    varVec.o <- yhat.o * (1-yhat.o)
    cutpoints <- equalVarCut(pred.o = yhat.o, g=g, weights.o = varVec.o)
    interval = cut(yhat,breaks=cutpoints, include.lowest = TRUE)
  }
  
  Y1 <- trials*y # Number of successes for each covariate combination (EVP), EVPs might not be aggregated yet
  Y0 <- trials - Y1 # Number of failures
  Y1hat <- trials*yhat # Expected number successes
  Y0hat <- trials - Y1hat # Expected number failures
  
  # Create two contingency tables
  obs = xtabs(formula = cbind(Y0, Y1) ~ interval) # A table of counts from each interval
  expect = xtabs(formula = cbind(Y0hat, Y1hat) ~ interval)
  if (any(expect < 5) & warnings)
    warning("Some expected counts are less than 5. Use smaller number of groups")
  
  # Pearson statistic
  pear <- (obs - expect)/sqrt(expect)
  chisq = sum(pear^2) # Chi-square statistics
  P = 1 - pchisq(chisq, g - 2) # g-2 degrees of freedom
  # by returning an object of class "htest", the function will perform like the
  # built-in hypothesis tests
  
  colnames(pear) <- c("p.res.Y0","p.res.Y1")
  countsTable = cbind(obs,expect,pear)
  countsTable2 = countsTable
  countsTable = as.data.frame(countsTable[ , c(2,4)])
  countsTable$NumObs <- countsTable2[,1] + countsTable2[,2]
  colnames(countsTable) <- c("Observed", "Expected", "NumObs")

  return(structure(list(
    method = c(paste("Hosmer and Lemeshow goodness-of-fit test with", g, "bins.",
                     "EVP input:",groupMode=='EVP',"Quantiles:",cuts=='quantiles',sep = " ")),
    data.name = deparse(substitute(obj)), # gives a string
    statistic = c(X2 = chisq),
    parameter = c(df = g-2),
    p.value = P,
    cutpoints = cutpoints,
    countsTable = countsTable # A contingency table
  ), class = 'htest')) # Hypothesis test class
}
