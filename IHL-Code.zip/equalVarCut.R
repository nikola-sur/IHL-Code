# This function is similar to 'equalMeanCutV2'. Instead of forming cutpoints so
# that the expected counts are roughly constant, it forms cutpoints so that the
# total variance within a group is approximately the same, since this is what
# will go on the denominator of the Pearson-like statistic.
#
# Need 'spatstat' package installed for 'weighted.quantile'
#
# Created: June 25, 2018

equalVarCut <- function(pred.o, g, weights.o) {
  pred.oU <- unique(pred.o) # Unique preds
  pred.oC <- as.numeric(table(pred.o)) # Counts for each pred
  weights.oU <- weights.o[!duplicated(pred.o)] # Same length as pred.oU

  if (length(pred.oU) < g) {
    stop("Please choose a smaller group number (not enough data points).")
  }

  cutpoints <- vector(mode="numeric",length=g+1)
  cutpoints[1] <- pred.oU[1] # Minimum
  cutpoints[g+1] <- pred.oU[length(pred.oU)] # Maximum

  for (gg in 2:g) {
    cutpoints[g-gg+2] <- spatstat::weighted.quantile(x=pred.oU,
                                           w=weights.oU*pred.oC,
                                           probs=(g-gg+1)/(g-gg+2))
    rmIndTemp <- pred.oU < cutpoints[g-gg+2]
    pred.oU <- pred.oU[rmIndTemp] # Remove covered elements
    pred.oC <- pred.oC[rmIndTemp] # Remove covered elements
    weights.oU <- weights.oU[rmIndTemp] # Remove covered elements
  }

  return(cutpoints)
}
