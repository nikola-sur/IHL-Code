#' Global GOF for GLMs
#'
#' @param obj GLM regression object
#' @param g The number of groups
#' @param groupMode The grouping method
#'
#' @export

globalgof <- function(obj, g, groupMode, warnings) {
  UseMethod("globalgof")
}
